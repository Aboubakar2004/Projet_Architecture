<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/css/output.css">
    <link rel="stylesheet" href="/src/input.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title></title>
</head>
<style>
    .active{
            font-weight: bold;
            text-transform: uppercase;
            font-size: 2rem;
        }
</style>

<body>
    <header class="flex flex-col gap-4 bg-white text-black w-full px-8 py-3">
        <nav class="flex justify-between items-center">
            <div class="flex md:hidden">
                <ion-icon class="cursor-pointer" name="menu-outline"></ion-icon>
            </div>
            <div class="cursor-pointer">
                BORUSSIA DORTMUND
            </div>
            <div class="flex items-center gap-2">
                <div class="cursor-pointer hidden md:flex">username</div>
                <div>
                    <img class="w-10 h-10 object-cover rounded-full cursor-pointer" src="https://www.shutterstock.com/image-vector/default-avatar-profile-icon-social-600nw-1677509740.jpg" alt="#">
                </div>
            </div>
        </nav>
        <nav class="menu">
            <ul class="hidden md:flex justify-between items-center">
                <li class="cursor-pointer">Débat</li>
                <li class="cursor-pointer">Photographie</li>
                <li class="cursor-pointer">Cinéma</li>
                <li class="cursor-pointer active">Musique</li>
                <li class="cursor-pointer">Littérature</li>
                <li class="cursor-pointer">Peinture</li>
                <li class="cursor-pointer">Wargamming</li>
            </ul>
        </nav>
    </header>

    <script>
        const $menuLis = document.querySelectorAll('.menu ul li');

        // const $pauseIcon = document.querySelector('div .pause.active');


        $menuLis.forEach($menuLi => {
            $menuLi.addEventListener('click', function() {

                $menuLis.forEach($otherLi => {
                    if ($otherLi !== $menuLi) {
                        $otherLi.classList.remove('active');
                    }
                });

                $menuLi.classList.add('active');
            });
        });
    </script>
</body>


</html>