<?php
include 'header2.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/css/output.css">
    <link rel="stylesheet" href="/src/input.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title></title>
</head>
<body style="background-color: black;">
<div class="bg-cover bg-center w-3/6 h-96 ml-32 mt-8 br-4 rounded-lg content-center" style="background-image: url(../galery/mu1.jpg)">
<h1 class="text-white ml-8  font-bold text-6xl font-inter justify-center relative top-4 "> TROUVE DES </h1>
<H1 class="text-[#FF9A02] ml-8 font-bold text-6xl font-inter justify-between relative top-4"> EVENEMENTS</H1>
<h1 class=" text-white ml-8 font-bold text-6xl font-inter justify-between relative top-4"> PRES DE TOI </h1>
<button class="bg-none hover:bg-black  text-white ml-8   border-2 border-[#FF9A02] rounded-lg relative top-12">
  UTILISER SA GEOLOCALISATION
</button>
</div>

<div class=" w-1/6 h-auto bg-white p-6 rounded-md shadow-md ml-auto -mt-96  mr-72">
        <img src="../galery/rock.jpg" alt="Affiche de l'album" class="w-6/6 h-22 object-cover mb-4 rounded-md">
        <h2 class="text-4 font-mono mb-1 -mt-3 ml-2">Daisy Jones & The Six</h2>
        <p class="text-gray-600 font-mono mb-1 ml-6 -mt-2">Nom de l'album</p>

        <div class="flex items-center justify-center mb-4">
      <button id="rewind" class="bg-gray-300 text-gray-700 p-2 rounded-full mr-4">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11 19l-7-7 7-7m8 14l-7-7 7-7"></path>
        </svg>
      </button>

      <button id="playPause" class="bg-[#FF9A02] text-white p-2 rounded-full mr-4">
        <svg id="playIcon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3l14 9L5 21V3z"></path>
        </svg>
      </button>

      <button id="fastForward" class="bg-gray-300 text-gray-700 p-2 rounded-full">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3l14 9L5 21V3z"></path>
        </svg>
      </button>
    </div>

    <div class="flex items-center justify-between">
      <span class="text-gray-600">0:00</span>
      <input type="range" class="w-2/3" />
      <span class="text-gray-600">3:30</span>
    </div>
        
        
        
        
            
        </div>
    </div>

    <div class="ml-32 mt-24">
      <h1 class="text-mono font-bold text-white text-2xl"> ALL EVENTS</h1>
      <h2 class="text-mono text-underline text-white text-5">Categorie</h2>
      <p class="text-mono  text-[#FFFFFF] text-1">Tech</p>
      <p class="text-mono  text-[#FFFFFF] text-1">Rock</p>
      <p class="text-mono  text-[#FFFFFF] text-1">Jazz</p>
      <p class="text-mono  text-[#FFFFFF] text-1">Classique</p>
      <p class="text-mono  text-[#FFFFFF] text-1">Pop Rock</p>
      <p class="text-mono font-bold text-[#FF9A02] text-1">Alternatif</p>
      <p class="text-mono  text-[#FFFFFF] text-1">House</p>
    </div>
    
</body>

<script>
      const playPauseButton = document.getElementById('playPause');
    const playIcon = document.getElementById('playIcon');
    const audio = new Audio('your-music-file.mp3');

    playPauseButton.addEventListener('click', () => {
      if (audio.paused) {
        audio.play();
        playIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 3l14 9L5 21V3z"></path>';
      } else {
        audio.pause();
        playIcon.innerHTML = '<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 19h-1V5h1v14zm9-14v14h1V5h-1z"></path>';
      }
    });

    document.getElementById('rewind').addEventListener('click', () => {
      audio.currentTime -= 10;
    });

    document.getElementById('fastForward').addEventListener('click', () => {
      audio.currentTime += 10;
    });
</script>
</html>