<?
require_once("bddconnexion.php");
session_start();


?>
