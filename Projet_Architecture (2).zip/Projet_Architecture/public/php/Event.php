<?php
include 'header2.php'
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/css/output.css">
    <link rel="stylesheet" href="/src/input.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title></title>
</head>
<body class="bg-white" style="background-color: black;">
<div class="rounded">
<div class="flex justify-center items-center h-screen text-mono">
    <div class="bg-black p-8 rounded shadow-md w-3/6 absolute  space-y-4 right-16" style="height: 500px;">
        

        <!-- Nom Artiste -->
        <div class="w-64">
            <label for="nomArtiste" class="block text-sm font-medium text-[#FF9A02] text-mono ">Nom Artiste</label>
            <input type="text" id="nomArtiste" name="nomArtiste" class="mt-1 p-2 w-full border rounded bg-white">
        </div>

        <!-- Nom Événement -->
        <div class="w-64">
            <label for="nomEvenement" class="block text-sm font-medium text-[#FF9A02] text-mono ">Nom Événement</label>
            <input type="text" id="nomEvenement" name="nomEvenement" class="mt-1 p-2 w-full border rounded bg-white">
        </div>

        <!-- Date/Heure -->
        <div class="w-64">
            <label for="dateHeure" class="block text-sm font-medium text-[#FF9A02] text-mono ">Date/Heure</label>
            <input type="datetime-local" id="dateHeure" name="dateHeure" class="mt-1 p-2 w-full border rounded bg-white">
        </div>

        <!-- Description -->
        <div class="w-3/4" style="width: 645px;">
            <label for="description" class="block text-sm font-medium text-[#FF9A02] text-mono ">Description</label>
            <textarea id="description" name="description" rows="3" class="mt-1 p-2 w-full border rounded bg-white"></textarea>
        </div>

        <!-- Localisation -->
        <div class="ml-96 w-64 absolute " style="margin-top: -370px;">
            <label for="localisation" class="block text-sm font-medium text-[#FF9A02] text-mono ">Localisation</label>
            <input type="text" id="localisation" name="localisation" class="mt-1 p-2 w-full border rounded bg-white">
        </div>

        <!-- Style Musical -->
        <div class="w-64 ml-96 absolute" style="margin-top: -290px;">
            <label for="styleMusical" class="block text-sm font-medium text-[#FF9A02] text-mono ">Style Musical</label>
            <input type="text" id="styleMusical" name="styleMusical" class="mt-1 p-2 w-full border rounded bg-white">
        </div>

        <!-- Nombre de Tickets -->
        <div class="w-64 ml-96 absolute"style="margin-top: -200px;" >
            <label for="nombreTickets" class="block text-sm font-medium text-[#FF9A02] text-mono ">Nombre de Tickets</label>
            <input type="number" id="nombreTickets" name="nombreTickets" class="mt-1 p-2 w-full border rounded bg-white">
        </div>

        <!-- Bouton Valider -->
        <div class="text-center absolute ml-72">
            <button type="button" class="bg-[#FF9A02] text-black px-4 py-2 rounded-full text-mono ">Valider</button>
        </div>
        
    </div>
    
</div>
<div class="bg-cover bg-center w-2/6 h-96  top-48 ml-44 absolute border-none content-center" style="background-image: url(../galery/rock.jpg)">
            <h1 class="text-white ml-8  font-bold text-4xl font-inter justify-center absolute top-8 "> YOUR NEW </h1>
            <h1 class="font-bold text-4xl font-inter absolute text-[#FF9A02] left-60 top-8">EVENT!</h1> 
            
        </div>

</div>

</body>
</html>
