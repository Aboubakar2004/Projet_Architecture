<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/public/css/output.css">
    <link rel="stylesheet" href="/src/input.css">
    <script src="https://cdn.tailwindcss.com"></script>
    <title></title>
</head>
<body class="bg-black">

    <header class="bg-white p-4 flex justify-between items-center">
        <!-- Logo -->
        <div class="flex items-center">
            <h1 class="font-bold text-black text-mono text-2xl">BORUSSIA DORTMUND</h1>
            
        </div>

        <!-- Liens -->
        <nav class="flex items-center space-x-12 font-mono">
            <a href="#" class="nav-link text-[#6b7280] hover:font-bold hover:text-black hover:text-2xl ">DEBAT</a>
            <a href="#" class="nav-link text-[#6b7280] hover:font-bold hover:text-black hover:text-2xl  ">PHOTOGRAPHIE</a>
            <a href="#" class="nav-link text-[#6b7280] hover:font-bold hover:text-black hover:text-2xl  ">CINEMA</a>
            <a href="#" class="nav-link font-bold text-2xl">MUSIQUE</a>
            <a href="#" class="nav-link text-[#6b7280] hover:font-bold hover:text-black hover:text-2xl  ">LITTERATURE</a>
            <a href="#" class="nav-link text-[#6b7280] hover:font-bold hover:text-black hover:text-2xl  ">PEINTURE</a>
            <a href="#" class="nav-link text-[#6b7280] hover:font-bold hover:text-black hover:text-2xl  ">WARGAMMING</a>
        </nav>

        <!-- Icon de profil -->
        <div class="flex items-center">
            <a href="" class="text-mono  text-[#6b7280] mr-2 hover:text-black hover:font-bold"><img src="../galery/icon utilisateur.png" alt="Profil" class="h-9 w-9 rounded-full mr-4 center "> Username</a>
        
        </div>
    </header>

</body>
</html>
