<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title></title>
</head>
<style>

.vertical-list {
            list-style-type: none;
            padding: 0;
            text-align: center;
        }

        .vertical-list li {
            margin: 10px 0;
        }

        .vertical-list a {
            text-decoration: none;
            color: #333;
            font-family: 'JetBrains Mono', 'monospace';

            /* font-weight: bold; */
            font-size: 18px;
            transition: color 0.3s;
        }

        .vertical-list a:hover {
            color: #FF9A02;
        }

</style>
<body>
    <hr>
    <footer>
        <div class="footer">
            <h3> BORUSSIA DORTMUND</h3>
            <div class="description">
                <p id="texte">
                Soutenir les artistes, <br>
                 c'est nourrir l'âme collective,<br>
                  cultiver la diversité culturelle <br>
                  et créer des ponts entre les cœurs <br>
                  à travers
                   l'expression créative qui  <br>transcende  
                   les frontières du quotidien.

                </p>
            </div>
            <div class="lien">
                <h4> ALL EVENT</h4>
                <div class="link">
                    <ul class="vertical-list">
                        <li><a href="#link1">Titre 1</a></li>
                        <li><a href="#link2">Titre 2</a></li>
                        <li><a href="#link3">Titre 3</a></li>
                        <li><a href="#link4">Titre 4</a></li>
                        <li><a href="#link5">Titre 5</a></li>
                        <li><a href="#link6">Titre 6</a></li>
                        <li><a href="#link7">Titre 7</a></li>
                        <li><a href="#link8">Titre 8</a></li>
                    </ul>

                </div>

                <div class="resaux">

                    

                </div>


            </div>



        </div>

    </footer>
</body>
</html>